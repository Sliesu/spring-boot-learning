package com.rbc.boot.springbootmp.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.rbc.boot.springbootmp.entity.UserDO;

public interface UserService extends IService<UserDO> {

}
