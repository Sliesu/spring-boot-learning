package com.rbc.boot.springbootmp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMpApplicationTests {

    @Test
    void contextLoads() {
    }

}
